#[doc(inline)]
pub use gdnative_derive::godot_wrap_method;
