use miniserde::Deserialize;

#[derive(Deserialize)]
struct TupleStruct(i32, i32);

fn main() {}
