use miniserde::Serialize;

#[derive(Serialize)]
struct TupleStruct(i32, i32);

fn main() {}
