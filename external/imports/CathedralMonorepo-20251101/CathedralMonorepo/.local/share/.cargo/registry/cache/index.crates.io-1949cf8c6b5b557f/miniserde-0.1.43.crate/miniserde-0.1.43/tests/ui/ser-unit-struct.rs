use miniserde::Serialize;

#[derive(Serialize)]
struct UnitStruct;

fn main() {}
