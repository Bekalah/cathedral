#!/usr/bin/env node
// ND-safe sentinel: currently a no-op placeholder.
// Future checks can assert contrast ratios or block motion-heavy assets.
console.log('ND-safe check: no-op (placeholder).');
