# Chapter Packs

Place curated chapter-level packs in this directory. Each JSON file should follow the same structure as node packs, but reference an entire chapter or arc.
