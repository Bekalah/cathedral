# Image Manifests

Store IIIF manifest snapshots or notes in this directory when a museum or library hosts the plate online. Large raster tiles remain on the institution's servers; we keep only the manifest and citation.
