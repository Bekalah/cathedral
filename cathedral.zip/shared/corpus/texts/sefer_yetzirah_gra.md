# Sefer Yetzirah (Gra Recension) — Chapter 1 excerpt

> Thirty-two wondrous paths of wisdom traced Yah, the Lord of Hosts, the God of Israel, living God and King of ages, merciful and gracious, sublime and exalted.
>
> He created His universe with three Sepharim: with Number, with Word, and with Script.

Translation adapted from a public domain transcription.
