# De Occulta Philosophia Libri Tres — Book I excerpt

> Magic is a faculty of wonderful virtue, full of most high mysteries, containing the most profound contemplation of most secret things, together with the nature, power, quality, substance, and virtues thereof.
>
> As the philosopher saith, the magician is conversant with hidden forms, and he doth seek to draw forth the latent seeds of nature, or the sparks of the celestial fire, that they may flash forth with light.

This excerpt is transcribed from the 1533 Cologne edition. Public domain.
