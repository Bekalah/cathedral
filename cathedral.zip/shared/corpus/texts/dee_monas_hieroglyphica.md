# Monas Hieroglyphica — Theorem I excerpt

> The Monad is the parent of numbers and the source of all unity. Whoever understands the power of the Monad receives the key to the ark of truth.
>
> Consider therefore the circle, the point, and the cross; for within them the hieroglyphic Monad reveals the harmony of the celestial orders.

Derived from John Dee's 1564 first edition. Public domain.
